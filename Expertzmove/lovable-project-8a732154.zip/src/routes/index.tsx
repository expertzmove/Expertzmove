import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  Bot, LineChart, Bell, Settings2, ShieldCheck, TrendingUp,
  Plug, SlidersHorizontal, Rocket, Check, Play, ArrowRight,
  Twitter, MessageCircle, Send, Youtube, Coffee, Flame,
} from "lucide-react";
import {
  Accordion, AccordionItem, AccordionTrigger, AccordionContent,
} from "@/components/ui/accordion";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Expertz Move — Trading, on autopilot" },
      { name: "description", content: "A small team building an AI trading toolkit that handles the screens so you don't have to. Daily top-gainer updates, live charts, bots that behave." },
      { property: "og:title", content: "Expertz Move — Trading, on autopilot" },
      { property: "og:description", content: "An AI trading toolkit with daily top-gainer updates and bots built by traders, for traders." },
    ],
  }),
  component: Landing,
});

/* ------------------ Hooks ------------------ */

function useInView<T extends HTMLElement>(once = true) {
  const ref = useRef<T | null>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
          if (once) io.disconnect();
        } else if (!once) setInView(false);
      },
      { threshold: 0.2 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [once]);
  return { ref, inView };
}

function useCountUp(target: number, start: boolean, duration = 1800) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!start) return;
    let raf = 0;
    const t0 = performance.now();
    const tick = (t: number) => {
      const p = Math.min(1, (t - t0) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(target * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, start, duration]);
  return val;
}

/* ------------------ Reveal wrapper ------------------ */

function Reveal({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  const { ref, inView } = useInView<HTMLDivElement>();
  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: inView ? 1 : 0,
        transform: inView ? "translateY(0)" : "translateY(24px)",
        transition: `opacity 0.7s ease ${delay}ms, transform 0.7s ease ${delay}ms`,
      }}
    >
      {children}
    </div>
  );
}

/* ------------------ Data ------------------ */

const TICKERS = [
  { s: "BTC/USD", p: "67,432.10", c: "+2.41%", up: true },
  { s: "ETH/USD", p: "3,548.22", c: "+1.87%", up: true },
  { s: "SOL/USD", p: "184.55", c: "-0.62%", up: false },
  { s: "AAPL", p: "228.91", c: "+0.94%", up: true },
  { s: "TSLA", p: "248.30", c: "-1.12%", up: false },
  { s: "SPY", p: "563.74", c: "+0.38%", up: true },
  { s: "NVDA", p: "134.05", c: "+3.22%", up: true },
  { s: "BNB/USD", p: "612.80", c: "+0.71%", up: true },
  { s: "DOGE/USD", p: "0.1632", c: "-2.04%", up: false },
  { s: "MSFT", p: "432.18", c: "+0.55%", up: true },
];

const STATS = [
  { label: "Members", value: 12400, suffix: "+", decimals: 0 },
  { label: "Avg. uptime", value: 99.2, suffix: "%", decimals: 1 },
  { label: "Pairs watched", value: 1850, suffix: "", decimals: 0 },
  { label: "Coffees this week", value: 47, suffix: "", decimals: 0 },
];

const STEPS = [
  { icon: Plug, title: "Plug in your exchange", desc: "Connect Binance, Coinbase, Bybit — whichever one you already use. Read/trade keys only, never withdraw." },
  { icon: SlidersHorizontal, title: "Pick a style that fits you", desc: "DCA if you're patient. Grid if you like sideways markets. AI mode if you'd rather not think about it tonight." },
  { icon: Rocket, title: "Let it run. Check in when you want", desc: "We'll send a daily recap. No constant pings, no fake urgency — just what actually happened." },
];

const FEATURES = [
  { icon: Bot, title: "Bots that behave", desc: "No mystery black box. You see every entry, exit, and the reason behind it." },
  { icon: LineChart, title: "Charts you'll actually use", desc: "Full TradingView under the hood, with our signals layered on so you don't squint." },
  { icon: Bell, title: "Alerts without the noise", desc: "Email, Telegram, push — only when something genuinely matters. Promise." },
  { icon: Settings2, title: "No-code strategy builder", desc: "If you can describe a trade out loud, you can build it. Backtest before you risk a cent." },
  { icon: ShieldCheck, title: "Risk rails, on by default", desc: "Stop-loss, trailing stops, daily loss limits. We turn them on for you so a bad day stays a bad day." },
  { icon: TrendingUp, title: "Honest portfolio view", desc: "Every exchange, every bot, every fee. No vanity numbers — including the trades that went sideways." },
];

const TESTIMONIALS = [
  { name: "Marcus Chen", role: "Part-time trader, Singapore", result: "+19% in Q3", quote: "I'm not glued to my phone anymore. The grid bot on ETH did its thing while I was on a trip with the kids. That alone is worth it." },
  { name: "Sofia Alvarez", role: "Day job + side portfolio", result: "+12% YTD", quote: "Honestly I was skeptical. But the daily recap email is just… useful. It tells me when nothing happened too, which I appreciate." },
  { name: "Devon Park", role: "Quant hobbyist", result: "+28% / 6mo", quote: "I rebuilt my old Python strategy in the no-code builder in about an hour. Backtest matched live within a couple of basis points." },
];

const FAQ = [
  { q: "Do I need to know how to trade?", a: "Nope. Most people start with our AI mode or a preset and tweak from there. If you do know what you're doing, the builder won't get in your way." },
  { q: "Is my money actually safe?", a: "Your funds stay on your exchange. We only ask for trade-only API keys — withdrawal permissions are off the table. You can revoke our access anytime from your exchange settings." },
  { q: "What if the bot has a bad day?", a: "It will. Markets do. We default to conservative risk caps and a daily loss limit, and the recap email is upfront when things didn't go well. No hiding the losers." },
  { q: "Who's behind this?", a: "We're a team of six — four traders, two engineers — based out of Lisbon and Bengaluru. You can reply to any email and it'll land in one of our inboxes, not a help desk queue." },
];

/* Top gainers — the symbols are the daily-rotated picks */
const TOP_GAINERS = [
  { symbol: "NASDAQ:NVDA", label: "NVDA" },
  { symbol: "BINANCE:SOLUSDT", label: "SOL" },
  { symbol: "NASDAQ:AMD", label: "AMD" },
  { symbol: "BINANCE:AVAXUSDT", label: "AVAX" },
];

/* ------------------ Page ------------------ */

function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Nav />
      <Hero />
      <Stats />
      <HowItWorks />
      <Features />
      <TopGainers />
      <ChartSection />
      <Pricing />
      <Testimonials />
      <Faq />
      <CtaBanner />
      <Footer />
    </div>
  );
}

/* ------------------ Nav ------------------ */

function Nav() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 backdrop-blur-md bg-background/60 border-b border-border/50">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <a href="#top" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-md bg-gradient-to-br from-cyan-glow to-violet-glow grid place-items-center">
            <span className="font-display font-bold text-background text-sm">E</span>
          </div>
          <span className="font-display font-bold tracking-wide">Expertz Move</span>
        </a>
        <nav className="hidden md:flex items-center gap-8 text-sm text-muted-foreground">
          <a href="#how" className="hover:text-foreground transition">How it works</a>
          <a href="#features" className="hover:text-foreground transition">What we built</a>
          <a href="#gainers" className="hover:text-foreground transition">Today's movers</a>
          <a href="#pricing" className="hover:text-foreground transition">Pricing</a>
          <a href="#faq" className="hover:text-foreground transition">FAQ</a>
        </nav>
        <a
          href="#pricing"
          className="text-sm font-medium px-4 py-2 rounded-md bg-cyan-glow text-background hover:opacity-90 transition"
        >
          Try it free
        </a>
      </div>
    </header>
  );
}

/* ------------------ Hero ------------------ */

function Hero() {
  return (
    <section id="top" className="relative min-h-screen flex flex-col justify-center pt-20 overflow-hidden">
      <video
        autoPlay
        muted
        loop
        playsInline
        poster="https://images.unsplash.com/photo-1642790106117-e829e14a795f?auto=format&fit=crop&w=1920&q=80"
        className="absolute inset-0 w-full h-full object-cover"
      >
        <source
          src="https://videos.pexels.com/video-files/8369976/8369976-uhd_2560_1440_25fps.mp4"
          type="video/mp4"
        />
      </video>
      <div className="absolute inset-0 bg-background/75" />
      <div className="absolute inset-0 bg-grid opacity-60" />
      <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-transparent to-background" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 w-full py-20">
        <div className="max-w-3xl animate-float-up">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-cyan-glow/30 bg-cyan-glow/5 text-xs font-mono text-cyan-glow mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-neon-green animate-pulse" />
            Built by traders who got tired of staring at screens
          </div>
          <h1 className="font-display text-5xl md:text-7xl lg:text-[5.5rem] font-bold leading-[0.98] tracking-tight">
            Your charts.
            <br />
            <span className="text-gradient-cyan">Our problem.</span>
          </h1>
          <p className="mt-6 text-lg md:text-xl text-muted-foreground max-w-2xl leading-relaxed">
            Expertz Move is an AI trading toolkit that takes the manual work off your plate — scanning markets, placing trades, and sending you a real human-readable recap at the end of the day.
          </p>
          <div className="mt-10 flex flex-wrap gap-4">
            <a
              href="#pricing"
              className="group inline-flex items-center gap-2 px-7 py-4 rounded-md bg-cyan-glow text-background font-semibold animate-pulse-glow hover:bg-cyan-glow/90 transition"
            >
              Start free — no card
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition" />
            </a>
            <a
              href="#gainers"
              className="inline-flex items-center gap-2 px-7 py-4 rounded-md border border-border bg-background/40 backdrop-blur-sm hover:border-cyan-glow/60 hover:bg-cyan-glow/5 transition font-semibold"
            >
              <Play className="w-4 h-4" /> See today's movers
            </a>
          </div>
          <p className="mt-6 text-xs text-muted-foreground/70 font-mono">
            P.S. — We don't promise lambos. We promise fewer 2am chart checks.
          </p>
        </div>
      </div>

      <Ticker />
    </section>
  );
}

function Ticker() {
  const items = [...TICKERS, ...TICKERS];
  return (
    <div className="relative z-10 border-y border-border/60 bg-background/80 backdrop-blur-md overflow-hidden">
      <div className="flex animate-ticker whitespace-nowrap py-3">
        {items.map((t, i) => (
          <div key={i} className="flex items-center gap-3 px-6 font-mono text-sm">
            <span className="text-muted-foreground">{t.s}</span>
            <span className="text-foreground">{t.p}</span>
            <span className={t.up ? "text-neon-green" : "text-neon-red"}>{t.c}</span>
            <span className="text-border">•</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ------------------ Stats ------------------ */

function Stats() {
  const { ref, inView } = useInView<HTMLDivElement>();
  return (
    <section className="py-16 border-b border-border/50">
      <div ref={ref} className="max-w-7xl mx-auto px-6">
        <div className="glass-card border-t-2 !border-t-cyan-glow grid grid-cols-2 md:grid-cols-4 gap-px bg-border/30 overflow-hidden">
          {STATS.map((s, i) => (
            <StatCell key={i} stat={s} start={inView} />
          ))}
        </div>
        <p className="mt-4 text-center text-xs text-muted-foreground/70 font-mono">
          Real numbers. The coffee count is honest too — <Coffee className="inline w-3 h-3 -mt-0.5" /> we keep a tally on the wall.
        </p>
      </div>
    </section>
  );
}

function StatCell({ stat, start }: { stat: typeof STATS[number]; start: boolean }) {
  const val = useCountUp(stat.value, start);
  const formatted = stat.value >= 1000
    ? Math.round(val).toLocaleString()
    : val.toFixed(stat.decimals);
  return (
    <div className="bg-surface p-8 md:p-10 text-center">
      <div className="font-mono text-3xl md:text-5xl font-semibold text-gradient-cyan">
        {formatted}{stat.suffix ?? ""}
      </div>
      <div className="mt-2 text-sm uppercase tracking-widest text-muted-foreground">{stat.label}</div>
    </div>
  );
}

/* ------------------ How it works ------------------ */

function HowItWorks() {
  return (
    <section id="how" className="relative py-28">
      <div className="absolute inset-0 bg-grid opacity-30" />
      <div className="relative max-w-7xl mx-auto px-6">
        <Reveal>
          <SectionHeader eyebrow="HOW IT WORKS" title="Three steps. Then go live your day." subtitle="Most people are up and running before their coffee goes cold." />
        </Reveal>
        <div className="mt-16 grid md:grid-cols-3 gap-6">
          {STEPS.map((s, i) => (
            <Reveal key={i} delay={i * 120}>
              <div className="glass-card glass-card-hover p-8 h-full">
                <div className="flex items-center justify-between mb-6">
                  <div className="w-12 h-12 rounded-md bg-cyan-glow/10 border border-cyan-glow/30 grid place-items-center">
                    <s.icon className="w-5 h-5 text-cyan-glow" />
                  </div>
                  <span className="font-mono text-5xl font-bold text-cyan-glow/20">0{i + 1}</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">{s.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{s.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ------------------ Features ------------------ */

function Features() {
  return (
    <section id="features" className="relative py-28 border-y border-border/50">
      <div
        className="absolute inset-0 opacity-20 bg-cover bg-center"
        style={{ backgroundImage: "url('https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=1920&q=80')" }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background/85 to-background" />
      <div className="relative max-w-7xl mx-auto px-6">
        <Reveal>
          <SectionHeader eyebrow="WHAT WE BUILT" title="The tools we wished we'd had" subtitle="Every feature here exists because one of us got tired of doing it by hand." />
        </Reveal>
        <div className="mt-16 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {FEATURES.map((f, i) => (
            <Reveal key={i} delay={i * 80}>
              <div className="glass-card glass-card-hover p-7 h-full group">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-glow/20 to-violet-glow/10 border border-cyan-glow/20 grid place-items-center mb-5 group-hover:border-cyan-glow/60 transition">
                  <f.icon className="w-5 h-5 text-cyan-glow" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{f.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ------------------ Top Gainers (daily) ------------------ */

function TopGainers() {
  const today = new Date().toLocaleDateString("en-US", {
    weekday: "long", month: "long", day: "numeric",
  });
  return (
    <section id="gainers" className="relative py-28">
      <div className="absolute inset-0 bg-grid opacity-25" />
      <div className="relative max-w-7xl mx-auto px-6">
        <Reveal>
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-12">
            <div>
              <div className="font-mono text-xs uppercase tracking-[0.25em] text-cyan-glow mb-3 flex items-center gap-2">
                <Flame className="w-3.5 h-3.5" /> TODAY'S MOVERS
              </div>
              <h2 className="font-display text-4xl md:text-5xl font-bold tracking-tight">
                What's actually <span className="text-gradient-cyan">running</span> today
              </h2>
              <p className="mt-4 text-muted-foreground max-w-xl leading-relaxed">
                Updated every day — the four names our bot flagged as standout movers, plus the live top-gainers board from TradingView. No editorial spin, just what the tape is doing.
              </p>
            </div>
            <div className="font-mono text-xs text-muted-foreground border border-border/60 rounded-md px-4 py-2 bg-surface/60">
              Last updated · {today}
            </div>
          </div>
        </Reveal>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Left: 4 mini charts of our picks */}
          <Reveal>
            <div className="grid sm:grid-cols-2 gap-4">
              {TOP_GAINERS.map((g) => (
                <div key={g.symbol} className="glass-card p-2">
                  <div className="px-2 pt-1 pb-2 flex items-center justify-between">
                    <span className="font-mono text-xs text-cyan-glow">{g.label}</span>
                    <span className="text-[10px] uppercase tracking-widest text-muted-foreground">Bot pick</span>
                  </div>
                  <MiniSymbolWidget symbol={g.symbol} />
                </div>
              ))}
            </div>
          </Reveal>

          {/* Right: live hotlist */}
          <Reveal delay={120}>
            <div className="glass-card p-3 h-full">
              <div className="px-2 pt-1 pb-3 flex items-center justify-between">
                <span className="font-mono text-xs text-cyan-glow">LIVE · TOP GAINERS</span>
                <span className="text-[10px] uppercase tracking-widest text-muted-foreground">via TradingView</span>
              </div>
              <HotlistWidget />
            </div>
          </Reveal>
        </div>

        <p className="mt-6 text-xs text-muted-foreground/70 italic">
          These aren't recommendations. We share them so you can see what the bot is watching — what you do with that is your call.
        </p>
      </div>
    </section>
  );
}

function MiniSymbolWidget({ symbol }: { symbol: string }) {
  const ref = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    if (!ref.current) return;
    ref.current.innerHTML = "";
    const container = document.createElement("div");
    container.className = "tradingview-widget-container__widget";
    ref.current.appendChild(container);
    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-mini-symbol-overview.js";
    script.async = true;
    script.innerHTML = JSON.stringify({
      symbol,
      width: "100%",
      height: 180,
      locale: "en",
      dateRange: "1D",
      colorTheme: "dark",
      isTransparent: true,
      autosize: false,
      largeChartUrl: "",
      chartOnly: false,
      noTimeScale: false,
    });
    ref.current.appendChild(script);
  }, [symbol]);
  return <div ref={ref} className="tradingview-widget-container" style={{ height: 180 }} />;
}

function HotlistWidget() {
  const ref = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    if (!ref.current) return;
    ref.current.innerHTML = "";
    const container = document.createElement("div");
    container.className = "tradingview-widget-container__widget";
    ref.current.appendChild(container);
    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-hotlists.js";
    script.async = true;
    script.innerHTML = JSON.stringify({
      colorTheme: "dark",
      dateRange: "1D",
      exchange: "US",
      showChart: true,
      locale: "en",
      largeChartUrl: "",
      isTransparent: true,
      showSymbolLogo: true,
      showFloatingTooltip: false,
      width: "100%",
      height: 540,
      plotLineColorGrowing: "rgba(0, 229, 255, 1)",
      plotLineColorFalling: "rgba(255, 84, 112, 1)",
      gridLineColor: "rgba(0, 229, 255, 0.06)",
      scaleFontColor: "rgba(180, 200, 220, 1)",
      belowLineFillColorGrowing: "rgba(0, 229, 255, 0.12)",
      belowLineFillColorFalling: "rgba(255, 84, 112, 0.12)",
      belowLineFillColorGrowingBottom: "rgba(0, 229, 255, 0)",
      belowLineFillColorFallingBottom: "rgba(255, 84, 112, 0)",
      symbolActiveColor: "rgba(0, 229, 255, 0.12)",
    });
    ref.current.appendChild(script);
  }, []);
  return <div ref={ref} className="tradingview-widget-container" style={{ height: 540 }} />;
}

/* ------------------ Chart section ------------------ */

function ChartSection() {
  const ref = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    if (!ref.current) return;
    ref.current.innerHTML = "";
    const container = document.createElement("div");
    container.className = "tradingview-widget-container__widget";
    container.style.height = "500px";
    ref.current.appendChild(container);
    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js";
    script.async = true;
    script.innerHTML = JSON.stringify({
      autosize: true,
      symbol: "BINANCE:BTCUSDT",
      interval: "60",
      timezone: "Etc/UTC",
      theme: "dark",
      style: "1",
      locale: "en",
      hide_side_toolbar: false,
      allow_symbol_change: true,
      backgroundColor: "rgba(15, 18, 30, 1)",
      gridColor: "rgba(0, 229, 255, 0.06)",
      support_host: "https://www.tradingview.com",
    });
    ref.current.appendChild(script);
  }, []);
  return (
    <section id="chart" className="py-28 border-t border-border/50">
      <div className="max-w-7xl mx-auto px-6">
        <Reveal>
          <SectionHeader
            eyebrow="POKE AROUND"
            title="Same chart we use every morning"
            subtitle="Full TradingView, drop-in. Change the symbol, draw on it, do your thing."
          />
        </Reveal>
        <Reveal delay={120}>
          <div className="mt-12 glass-card p-2 md:p-3">
            <div ref={ref} className="tradingview-widget-container rounded-md overflow-hidden" style={{ height: 500 }} />
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ------------------ Pricing ------------------ */

const PLANS = [
  {
    name: "Just looking", price: "$0", period: "forever",
    features: ["1 bot, paper trading only", "Daily top-gainer email", "Basic alerts", "Community Discord"],
    cta: "Start free", highlight: false,
  },
  {
    name: "Most folks", price: "$39", period: "/month",
    features: ["5 live bots, any exchange", "All strategies + backtesting", "Real-time alerts (email/Telegram)", "We reply within a day"],
    cta: "Go with this one", highlight: true,
  },
  {
    name: "Power user", price: "$129", period: "/month",
    features: ["Unlimited bots", "API + webhooks", "Custom signal subscription", "Direct line to the team"],
    cta: "I want it all", highlight: false,
  },
];

function Pricing() {
  return (
    <section id="pricing" className="relative py-28 border-t border-border/50">
      <div className="absolute inset-0 bg-grid opacity-30" />
      <div className="relative max-w-7xl mx-auto px-6">
        <Reveal>
          <SectionHeader eyebrow="PRICING" title="Pay us when we earn it" subtitle="Start on the free plan. Move up only when the bot has paid for itself a few times over." />
        </Reveal>
        <div className="mt-16 grid md:grid-cols-3 gap-6">
          {PLANS.map((p, i) => (
            <Reveal key={p.name} delay={i * 100}>
              <div
                className={`relative glass-card p-8 h-full flex flex-col ${
                  p.highlight ? "border-cyan-glow/60 animate-pulse-glow" : ""
                }`}
              >
                {p.highlight && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-cyan-glow text-background text-xs font-semibold uppercase tracking-wider">
                    What we'd pick
                  </span>
                )}
                <h3 className="text-xl font-semibold">{p.name}</h3>
                <div className="mt-4 flex items-baseline gap-1">
                  <span className="font-mono text-5xl font-bold">{p.price}</span>
                  <span className="text-muted-foreground text-sm">{p.period}</span>
                </div>
                <ul className="mt-8 space-y-3 flex-1">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-3 text-sm">
                      <Check className="w-4 h-4 mt-0.5 text-neon-green shrink-0" />
                      <span className="text-muted-foreground">{f}</span>
                    </li>
                  ))}
                </ul>
                <a
                  href="#"
                  className={`mt-8 block text-center px-5 py-3 rounded-md font-semibold transition ${
                    p.highlight
                      ? "bg-cyan-glow text-background hover:opacity-90"
                      : "border border-border hover:border-cyan-glow/60 hover:bg-cyan-glow/5"
                  }`}
                >
                  {p.cta}
                </a>
              </div>
            </Reveal>
          ))}
        </div>
        <p className="mt-8 text-center text-sm text-muted-foreground">
          Cancel anytime in two clicks. We won't email you a guilt trip.
        </p>
      </div>
    </section>
  );
}

/* ------------------ Testimonials ------------------ */

function Testimonials() {
  return (
    <section className="relative py-28 border-y border-border/50">
      <div
        className="absolute inset-0 opacity-15 bg-cover bg-center"
        style={{ backgroundImage: "url('https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=1920&q=80')" }}
      />
      <div className="absolute inset-0 bg-background/80" />
      <div className="relative max-w-7xl mx-auto px-6">
        <Reveal>
          <SectionHeader eyebrow="WHAT MEMBERS SAY" title="Unfiltered, including the awkward bits" />
        </Reveal>
        <div className="mt-16 grid md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t, i) => (
            <Reveal key={t.name} delay={i * 100}>
              <div className="glass-card glass-card-hover p-7 h-full flex flex-col">
                <p className="text-foreground leading-relaxed flex-1">"{t.quote}"</p>
                <div className="mt-6 pt-6 border-t border-border/50 flex items-center gap-4">
                  <div className="w-11 h-11 rounded-full bg-gradient-to-br from-cyan-glow to-violet-glow grid place-items-center font-display font-bold text-background">
                    {t.name[0]}
                  </div>
                  <div className="flex-1">
                    <div className="font-semibold text-sm">{t.name}</div>
                    <div className="text-xs text-muted-foreground">{t.role}</div>
                  </div>
                  <div className="font-mono text-sm text-neon-green">{t.result}</div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ------------------ FAQ ------------------ */

function Faq() {
  return (
    <section id="faq" className="py-28">
      <div className="max-w-3xl mx-auto px-6">
        <Reveal>
          <SectionHeader eyebrow="QUESTIONS WE GET A LOT" title="Ask us anything else over email" />
        </Reveal>
        <Reveal delay={100}>
          <div className="mt-12 glass-card px-6">
            <Accordion type="single" collapsible>
              {FAQ.map((f, i) => (
                <AccordionItem key={i} value={`item-${i}`} className="border-border/60">
                  <AccordionTrigger className="text-base font-medium py-5">{f.q}</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed">{f.a}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ------------------ CTA banner ------------------ */

function CtaBanner() {
  return (
    <section className="py-20">
      <div className="max-w-7xl mx-auto px-6">
        <Reveal>
          <div
            className="relative rounded-2xl overflow-hidden p-12 md:p-20 text-center animate-gradient"
            style={{
              backgroundImage:
                "linear-gradient(135deg, oklch(0.25 0.1 240), oklch(0.22 0.15 290), oklch(0.2 0.12 200))",
            }}
          >
            <div className="absolute inset-0 bg-grid opacity-30" />
            <div className="relative">
              <h2 className="font-display text-4xl md:text-6xl font-bold tracking-tight">
                Give your eyes a break. <span className="text-gradient-cyan">Let it run.</span>
              </h2>
              <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
                Spin up your first bot in a few minutes. If it's not for you, no hard feelings — and no card up front either.
              </p>
              <a
                href="#pricing"
                className="mt-8 inline-flex items-center gap-2 px-8 py-4 rounded-md bg-cyan-glow text-background font-semibold hover:opacity-90 transition"
              >
                Try Expertz Move — free
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ------------------ Footer ------------------ */

function Footer() {
  return (
    <footer className="border-t border-border/60 bg-surface/40">
      <div className="max-w-7xl mx-auto px-6 py-14">
        <div className="grid md:grid-cols-4 gap-10">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-md bg-gradient-to-br from-cyan-glow to-violet-glow grid place-items-center">
                <span className="font-display font-bold text-background text-sm">E</span>
              </div>
              <span className="font-display font-bold tracking-wide">Expertz Move</span>
            </div>
            <p className="mt-4 text-sm text-muted-foreground max-w-sm leading-relaxed">
              A small team building trading tools we actually use ourselves. Based in Lisbon & Bengaluru — replies usually within a day.
            </p>
            <div className="mt-6 flex items-center gap-3">
              {[Twitter, MessageCircle, Send, Youtube].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-9 h-9 rounded-md border border-border grid place-items-center hover:border-cyan-glow/60 hover:text-cyan-glow transition"
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>
          <div>
            <div className="text-sm font-semibold mb-3">Product</div>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#features" className="hover:text-foreground transition">What we built</a></li>
              <li><a href="#gainers" className="hover:text-foreground transition">Today's movers</a></li>
              <li><a href="#pricing" className="hover:text-foreground transition">Pricing</a></li>
            </ul>
          </div>
          <div>
            <div className="text-sm font-semibold mb-3">The team</div>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-foreground transition">Our story</a></li>
              <li><a href="#" className="hover:text-foreground transition">Notes & writing</a></li>
              <li><a href="mailto:hi@expertzmove.com" className="hover:text-foreground transition">hi@expertzmove.com</a></li>
            </ul>
          </div>
        </div>
        <div className="mt-10 pt-6 border-t border-border/60 flex flex-col md:flex-row gap-3 md:items-center md:justify-between text-xs text-muted-foreground">
          <p>© {new Date().getFullYear()} Expertz Move. Built with too much coffee.</p>
          <p className="max-w-2xl">
            We're not your financial advisor. Trading involves real risk and past performance isn't a promise of anything.
          </p>
        </div>
      </div>
    </footer>
  );
}

/* ------------------ Shared ------------------ */

function SectionHeader({ eyebrow, title, subtitle }: { eyebrow: string; title: string; subtitle?: string }) {
  return (
    <div className="text-center max-w-2xl mx-auto">
      <div className="font-mono text-xs uppercase tracking-[0.25em] text-cyan-glow mb-4">{eyebrow}</div>
      <h2 className="font-display text-4xl md:text-5xl font-bold tracking-tight">{title}</h2>
      {subtitle && <p className="mt-4 text-muted-foreground leading-relaxed">{subtitle}</p>}
    </div>
  );
}
